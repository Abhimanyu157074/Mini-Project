package com.capg.uas.service;

import java.sql.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.uas.bean.Applicant;
import com.capg.uas.bean.ProgramOffered;
import com.capg.uas.bean.ProgramScheduled;
import com.capg.uas.bean.Users;
import com.capg.uas.dao.AdminDaoImpl;
import com.capg.uas.dao.IAdminDao;
import com.capg.uas.exception.UASException;

public class AdminServiceImpl implements IAdminService {
	
	private IAdminDao adminDao;
	
	public AdminServiceImpl() {
		adminDao=new AdminDaoImpl();
	}

	@Override
	public boolean validateAdmin(String userName, String password) throws UASException {
		boolean validity =false;
		String role="Admin";
		Users user = adminDao.getUserByName(userName);
		if(user==null)
			throw new UASException("No Such Login Id");
		else if(!password.equals(user.getPassword())  )
			throw new UASException("Password Mismatch");
		else if(!role.matches(user.getRole()))
			throw new UASException("Role Mismatch");
		
		else
			validity=true;
		
		return validity;
	}

	@Override
	public String addProgramOffered(ProgramOffered progOffered)
			throws UASException {
		String programOffer = null;
		if(progOffered!=null && isValidProgram(progOffered)){
			programOffer=adminDao.addProgramOffered(progOffered);
		}
		return programOffer;
	}

	@Override
	public String updateProgramOffered(ProgramOffered progOffered)
			throws UASException {
		
		return adminDao.updateProgramOffered(progOffered);
	}

	@Override
	public boolean deleteProgramOffered(String progName) throws UASException {
		boolean success = false;
		if(progName!=null && isValidName(progName)){
			success=adminDao.deleteProgramOffered(progName);
		}
		return success;
	}

	@Override
	public List<ProgramOffered> getAllOfferedPrograms() throws UASException {

		return adminDao.getAllOfferedPrograms();
	}

	@Override
	public String addProgramScheduled(ProgramScheduled progScheduled)
			throws UASException {
		String programSchedule = null;
		if(progScheduled!=null && isValidProgramSchedule(progScheduled)){
			programSchedule=adminDao.addProgramScheduled(progScheduled);
		}
		return programSchedule;
	}

	@Override
	public boolean deleteProgramScheduled(String progId) throws UASException {
		boolean success = false;
		if(progId!=null && isValidName(progId)){
			success=adminDao.deleteProgramScheduled(progId);
		}
		return success;
	}

	@Override
	public List<ProgramScheduled> getDatedProgramsSchedule(Date fromDateSQL,
			Date toDateSQL) throws UASException {
		List<ProgramScheduled> progList = null;
		if(fromDateSQL!=null && toDateSQL!=null && isValidDate(fromDateSQL,toDateSQL)){
			progList = adminDao.getDatedProgramsSchedule(fromDateSQL, toDateSQL);
		}
		return progList;
	}

	@Override
	public List<Applicant> viewCandidates(Applicant applicants)
			throws UASException {
		List<Applicant> appList = null;
		if(  isValidName(applicants.getScheduleProgId())){
			appList = adminDao.viewCandidates(applicants);
		}
		return appList;
		
	}


	

	public boolean isValidProgram(ProgramOffered program) throws UASException{
		return isValidDesc(program.getDesc()) && isValidEligibility(program.getAppEligibility()) &&
		isValidDuration(program.getDuration()) && isValidName(program.getProgName())
		&& isValidDegree(program.getDegreeOffered());
	}
	
	public boolean isValidDesc(String desc) throws UASException{
		Pattern descPattern = Pattern.compile("[A-Za-z0-9\\s]{5,20}");
		Matcher descMatcher = descPattern.matcher(desc);
		
		boolean isValid=descMatcher.matches();
		if(!isValid)
			throw new UASException("Description must have 5 characters and 20 characters atmost");
		return isValid;
	}
	
	public boolean isValidEligibility(String eligibility) throws UASException{
		Pattern eligibilityPattern = Pattern.compile("[A-Za-z0-9\\s]{10,40}");
		Matcher eligibilityMatcher = eligibilityPattern.matcher(eligibility);
		
		boolean isValid=eligibilityMatcher.matches();
		if(!isValid)
			throw new UASException("Eligibility must be atleast 10 chars in length and atmost 40 characters ");
		return isValid;
	}

	public boolean isValidDegree(String degree) throws UASException {
		Pattern degreePattern = Pattern.compile("[A-Za-z0-9\\s]{5,10}");
		Matcher degreeMatcher = degreePattern.matcher(degree);
		
		boolean isValid=degreeMatcher.matches();
		if(!isValid)
			throw new UASException("Degree Offered must have 5 characters and 10 characters atmost");
		return isValid;
	}

	public boolean isValidDuration(int duration) throws UASException  {
		String period = Integer.toString(duration);
		Pattern durationPattern = Pattern.compile("[1-9]{1}[0-9]{0-1}");
		Matcher durationMatcher = durationPattern.matcher(period);
		
		boolean isValid=durationMatcher.matches();
		if(!isValid)
			throw new UASException("Program Name must have 5 characters atmost");
		return isValid;
	}

	public boolean isValidName(String progName) throws UASException {
		Pattern namePattern = Pattern.compile("[A-Za-z0-9]{ ,5}");
		Matcher nameMatcher = namePattern.matcher(progName);
		
		boolean isValid=nameMatcher.matches();
		if(!isValid)
			throw new UASException("Program Name must have 5 characters atmost");
		return isValid;
		
	}
	
	
	
	public boolean isValidProgramSchedule(ProgramScheduled program) throws UASException{
		return isValidName(program.getScheduleProgId()) && isValidDegree(program.getLocation()) &&
		isValidDuration(program.getSessionsPerWeek()) && isValidName(program.getProgName())
		&& isValidDate(program.getStart(),program.getEnd());
	}

	public boolean isValidDate(Date start, Date end) {
		
		boolean isValid = false;
		
	        if(start.after(end)){
	            System.out.println("Start Date is after End Date");
	            isValid = false;
	        }
	        else if(start.before(end)){
	            System.out.println("Start Date is before End Date");
	            isValid = true;
	        }
	        else if(start.equals(end)){
	            System.out.println("Start Date is same as End Date");
	            isValid = false;
	        }

			return isValid;
	    }

	
}
