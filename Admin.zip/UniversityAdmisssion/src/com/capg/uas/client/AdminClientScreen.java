package com.capg.uas.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.capg.uas.bean.Applicant;
import com.capg.uas.bean.ProgramOffered;
import com.capg.uas.bean.ProgramScheduled;
import com.capg.uas.exception.UASException;
import com.capg.uas.service.AdminServiceImpl;
import com.capg.uas.service.IAdminService;


public class AdminClientScreen {

	static int loginAttempts = 0;
	private Scanner scan;
	private int choose;
	private IAdminService adminService;
	private SimpleDateFormat myFormat;

	public void start() throws UASException {
		int choice = -1;

		IAdminService adminService = new AdminServiceImpl();
		scan = new Scanner(System.in);
		myFormat = new SimpleDateFormat("dd/MM/yyyy");
		myFormat.setLenient(false);
		while (choice != 2 && loginAttempts <= 3) {
			System.out.print("[1]Login [2]Quit >");
			choice = scan.nextInt();

			if (choice == 1) {
				System.out.print("Login ID? ");
				String userName = scan.next();
				System.out.print("Password? ");
				String password = scan.next();
				loginAttempts++;
				try {
					if (adminService.validateAdmin(userName, password)) {
						System.out.println("Susscessfully Login");
						// switch options
						int option = 0;
						System.out.println(" Enter your Choice from below");
						System.out.println(" 1. Manage information of the programs offered by the university");
						System.out.println(" 2. Manage schedule of the programs offered by the university");
						System.out.println(" 3. View Reports");
						System.out.println(" 4. Exit");
						option = scan.nextInt();
						
						
						
						switch (option) {
						case 1:
							managePrograms();
							break;

							
						case 2: 
							manageProgramSchedule();							
							break;
							
						case 3: 
							displayLists();
							break;
							
						case 4:
							System.out.println("Thank you "+userName+".\n Please visit again.");
							System.exit(0);
						
						default:
							System.out.println("Please enter valid input");
							
						}
					} else {
						System.out.println("Please Login Again");
						
					}
				} catch (UASException e) {
					e.printStackTrace();
				}

			}
			else if(choice==2){
				System.out.println("Exiting the Application");
				System.exit(0);
			}
		}
		scan.close();
		System.out.println("Program Terminated");
	}
	

	public void displayLists() {
		
		System.out.println("Program Schedule Management mode activated");
		while(true){
			int choose = 0;
			System.out.println(" Enter your Choice from below");
			System.out.println(" 1. Applicant Report ");
			System.out.println(" 2. Report of Programs Scheduled in given time period");
			System.out.println(" 3. Exit");
			choose = scan.nextInt();
			
			Applicant applicants = new Applicant();
			
			switch(choose){
			case 1:
				try {	
				System.out.println("Applicant Report View Initiated");
				System.out.println("*************************************************************************");
				System.out.print("Enter Scheduled Program Id : ");
				String scheduleProgId = scan.next();
				System.out.println("\nEntering the Scheduled Program ID : "+scheduleProgId.toUpperCase());
				applicants.setScheduleProgId(scheduleProgId.toUpperCase());
				
				System.out.println("\nAPPLICANT'S ACCEPTED");
				applicants.setStatus("ACCEPTED");
				List<Applicant> confirmList;
				
					confirmList = adminService.viewCandidates(applicants);
				
				
				if (confirmList != null) {
					System.out
						.println("\tApplicant Id\tApplicant Name\tDOB\tQualification\tMarks\tGoals\t\tEmail\t\tProg Id\t\tInterview date");
					System.out
						.println("-----------------------------------------------------------------------------------------------------------------------------------");
					for (Applicant applicant : confirmList) {
					System.out
						.println(String
							.format("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\t%s",
									applicant.getAppId(),
									applicant.getAppName(),
									applicant.getAppDOB(),
									applicant.getQualification(),
									applicant.getMarks(),
									applicant.getGoals(),
									applicant.getEmailId(),
									applicant.getScheduleProgId(),
									applicant.getDateOfInterview()));
					}
				} else {
					System.out.println("No Records Found!");
				}

				System.out.println("\nAPPLICANT'S CONFIRMED FOR INTERVIEW");
				applicants.setStatus("CONFIRMED");
				List<Applicant> appList = adminService.viewCandidates(applicants);
				if (appList != null) {
					System.out
						.println("\t Applicant Id\tApplicant Name\tDOB\tQualification\tMarks\tGoals\t\tEmail\t\tProg Id\t\tInterview date");
					System.out
						.println("-----------------------------------------------------------------------------------------------------------------------------------");
					for (Applicant applicant : appList) {
					System.out
						.println(String
							.format("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\t%s",
									applicant.getAppId(),
									applicant.getAppName(),
									applicant.getAppDOB(),
									applicant.getQualification(),
									applicant.getMarks(),
									applicant.getGoals(),
									applicant.getEmailId(),
									applicant.getScheduleProgId(),
									applicant.getDateOfInterview()));
					}
				} else {
					System.out.println("No Records Found!");
				}
				
				System.out.println("\nAPPLICANT'S REJECTED");
				applicants.setStatus("REJECTED");
				List<Applicant> rejectList = adminService.viewCandidates(applicants);
				if (rejectList != null) {
					System.out
						.println("\tApplicant Id\tApplicant Name\tDOB\tQualification\tMarks\tGoals\t\tEmail\t\tProg Id\t\tInterview date");
					System.out
						.println("-----------------------------------------------------------------------------------------------------------------------------------");
					for (Applicant applicant : rejectList) {
					System.out
						.println(String
							.format("\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\t%s",
									applicant.getAppId(),
									applicant.getAppName(),
									applicant.getAppDOB(),
									applicant.getQualification(),
									applicant.getMarks(),
									applicant.getGoals(),
									applicant.getEmailId(),
									applicant.getScheduleProgId(),
									applicant.getDateOfInterview()));
					}
				} else {
					System.out.println("No Records Found!");
				}

			} catch (UASException exc) {
				System.err.println(exc.getMessage());
			}
				break;
				
			case 2:
				try {
				System.out.println("Reports of programs to be commenced in the given time period");
				
				java.sql.Date  fromDateSQL = null;
				java.sql.Date  toDateSQL = null;
				System.out.println("Enter Start Date of Program in DD/MM/YYYY format:");
				String fromDate = scan.nextLine();
				
				if(null != fromDate && fromDate.trim().length() > 0){
					
				    try {
						Date start = myFormat.parse(fromDate);
						fromDateSQL = new java.sql.Date(start.getTime());
						
					} catch (ParseException e) {
						System.err.println("Date is of Invalid format. Please try again");
						break;
					}
				}

				System.out.print("Enter End Date of Program in DD/MM/YYYY format: ");
				String toDate = scan.nextLine();
				
				if(null != toDate && toDate.trim().length() > 0){
					
				    try {
						Date end =  myFormat.parse(toDate);
						toDateSQL = new java.sql.Date(end.getTime());
						
					} catch (ParseException e) {
						System.err.println("Date is of Invalid format. Please try again");
						break;
					}
				}

				List<ProgramScheduled> programScheduleList = new ArrayList<>();
				
				
					programScheduleList = adminService.getDatedProgramsSchedule(fromDateSQL,toDateSQL);
				

				if (!programScheduleList.isEmpty()) {
					System.out.println("Program Name\tDescription\tApplicant Eligibilty\tDuration\tDegree Offered");
					System.out.println("-------------------------------------------------------------------------------------------------------");
					for (ProgramScheduled programScheduled : programScheduleList) {
						System.out.println(String.format("%s\t%s\t%s\t\t%s\t%s\t%s",
										programScheduled.getScheduleProgId(), programScheduled.getProgName(), 
										programScheduled.getLocation(),programScheduled.getStart(), 
										programScheduled.getEnd(),programScheduled.getSessionsPerWeek()));
					}
					
				} else {
					System.out.println("No Records Found!");
				}
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				break;
				
			case 3:
				System.out.println("Reports have been shown");
				System.exit(0);
				break;
			
			default:
				System.out.println("Invalid input");
				System.out.println("Please try again");
			}

		
		}
		
	}

	public void manageProgramSchedule() {
		System.out.println("Program Schedule Management mode activated");
		while(true){
			int choose = 0;
			System.out.println(" Enter your Choice from below");
			System.out.println(" 1. Add Program ");
			System.out.println(" 2. Delete Program");
			System.out.println(" 3. Exit");
			choose = scan.nextInt();
			
			ProgramScheduled progScheduled = new ProgramScheduled();
			
			switch(choose){
			case 1:
				
				
				
				System.out.print("Enter Scheduled Program Id : ");
				String scheduleProgId = scan.next();
				System.out.println("\nEntering the Scheduled Program ID : "+scheduleProgId.toUpperCase());
				progScheduled.setScheduleProgId(scheduleProgId.toUpperCase());
				
				try {
					
					List<ProgramOffered> programOfferedList = new ArrayList<>();
					
					programOfferedList = adminService.getAllOfferedPrograms();

					if (!programOfferedList.isEmpty()) {
						System.out.println("Program Name\tDescription\tApplicant Eligibilty\tDuration\tDegree Offered");
						System.out.println("-------------------------------------------------------------------------------------------------------");
						for (ProgramOffered programOffered : programOfferedList) {
							System.out.println(String.format("%s\t\t\t%s\t\t%s\t\t%s\t%s",
											programOffered.getProgName(), programOffered.getDesc(),
											programOffered.getAppEligibility(), programOffered.getDuration(),
											programOffered.getDegreeOffered()));
						}
					} else {
						System.out.println("No Records Found!");
					}
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				System.out.print("Enter Program Name from the above list : ");
				String progName = scan.next();
				System.out.println("\nEntering the Scheduled Program ID : "+progName.toUpperCase());
				progScheduled.setProgName(progName.toUpperCase());
				System.out.println("Enter Location :");
				scan.nextLine();
				progScheduled.setLocation(scan.nextLine());
				System.out.println("Enter Start Date of Program in DD/MM/YYYY format:");
				String startDate = scan.nextLine();
				
				if(null != startDate && startDate.trim().length() > 0){
				    try {
						Date start = myFormat.parse(startDate);
						java.sql.Date startDateSQL = new java.sql.Date(start.getTime());
						progScheduled.setStart(startDateSQL);
					} catch (ParseException e) {
						System.err.println("Date is of Invalid format. Please try again");
						break;
					}
				}
			
				System.out.print("Enter End Date of Program in DD/MM/YYYY format: ");
				String endDate = scan.nextLine();
				
				if(null != endDate && endDate.trim().length() > 0){
				    try {
						Date end =  myFormat.parse(endDate);
						java.sql.Date endDateSQL = new java.sql.Date(end.getTime());
						progScheduled.setStart(endDateSQL);
					} catch (ParseException e) {
						System.err.println("Date is of Invalid format. Please try again");
						break;
					}
				}
				System.out.println("Enter No. of Sessions per Week :");
				progScheduled.setSessionsPerWeek(scan.nextInt());
				
				try {
					String scheduledProgId = adminService.addProgramScheduled(progScheduled);
					if (scheduledProgId == null)
						System.err.println("Program Schedule Addition Failed!");
					else
						System.out.println("Program Schedule Added! with id " + scheduledProgId);
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				break;
				
			case 2:
				
				System.out.print("Enter Scheduled Program ID which needs to be deleted : ");
				String progId = scan.next();
				
				try {
					boolean success = adminService.deleteProgramScheduled(progId);
					if (!success)
						System.err.println("Program Schedule Deletion Failed!");
					else
						System.out.println("Program " + progId+" Deleted!");
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				break;
				
			case 3:
				System.out.println("Schedule of Programs has been managed");
				System.exit(0);
				break;
			
			default:
				System.out.println("Invalid input");
				System.out.println("Please try again");
			}

		
		}
		
	}

	public void managePrograms() {
		System.out.println("Program Management mode activated");
		while(true){
			choose = 0;
			System.out.println(" Enter your Choice from below");
			System.out.println(" 1. Add Program ");
			System.out.println(" 2. Update Program");
			System.out.println(" 3. Delete Program");
			System.out.println(" 4. Exit");
			choose = scan.nextInt();
			
			ProgramOffered progOffered = new ProgramOffered();
			String proName;
			
			switch(choose){
			case 1:
				
				System.out.print("Enter Program Name : ");
				proName = scan.next();
				System.out.println("\nEntering the Program Name : "+proName.toUpperCase());
				progOffered.setProgName(proName.toUpperCase());
				System.out.println("Enter Program Description :");
				scan.nextLine();
				progOffered.setDesc(scan.nextLine());
				System.out.println("Enter Applicant Eligibility :");
				progOffered.setAppEligibility(scan.nextLine());
				System.out.print("Enter Program Duration : ");
				progOffered.setDuration(scan.nextInt());
				System.out.println("Enter details of Degree Offered :");
				progOffered.setDegreeOffered(scan.next());
				
				try {
					String progName = adminService.addProgramOffered(progOffered);
					if (progName == null)
						System.err.println("Program addition Failed!");
					else
						System.out.println("Program Added! with name " + progName);
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				break;
				
			case 2:
				
				System.out.print("Enter Program Name which needs to be updated : ");
				proName = scan.next();
				System.out.println("\nEntering the Program Name to be updated : "+proName.toUpperCase());
				progOffered.setProgName(proName.toUpperCase());
				
				
				System.out.println("Enter Updated Program Description :");
				scan.nextLine();
				progOffered.setDesc(scan.nextLine());
				System.out.println("Enter Updated Applicant Eligibility :");
				scan.nextLine();
				progOffered.setAppEligibility(scan.nextLine());
				
				try {
					String progName = adminService.updateProgramOffered(progOffered);
					if (progName == null)
						System.err.println("Program Update Failed!");
					else
						System.out.println("Program " + progName+" Updated!");
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				break;
				
			case 3:
				
				System.out.print("Enter Program Name which needs to be deleted : ");
				String progName = scan.next();
				
				try {
					boolean success = adminService.deleteProgramOffered(progName.toUpperCase());
					if (!success)
						System.err.println("Program Deletion Failed!");
					else
						System.out.println("Program " + progName+" Deleted!");
				} catch (UASException e) {
					System.err.println(e.getMessage());
				}
				
				break;
				
			case 4:
				System.out.println("Programs offered by university have been managed");
				System.exit(0);
				break;
			
			default:
				System.out.println("Invalid input");
				System.out.println("Please try again");
			}

		
		}
		
	}

}
	
	
