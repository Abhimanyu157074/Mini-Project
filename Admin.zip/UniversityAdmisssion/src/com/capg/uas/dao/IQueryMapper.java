package com.capg.uas.dao;

public interface IQueryMapper {
	
	public static final String GET_USER="SELECT * FROM Users WHERE login_id=?";
	
	public static final String FIND_APPLICANT_PROG_ID_STATUS ="SELECT * FROM (SELECT * FROM Application WHERE Scheduled_program_id= ? ) WHERE status=?";

	public static final String ADD_PROGRAM_OFFERED_QUERY = "INSERT INTO Programs_Offered VALUES (?,?,?,?,?)";

	public static final String ADD_PROGRAM_SCHEDULED_QUERY = "INSERT INTO Programs_Scheduled VALUES (?,?,?,?,?,?)";

	public static final String UPDATE_PROGRAM_OFFERED_QUERY = "UPDATE Programs_Offered SET description= ?, applicant_eligibility= ? WHERE ProgramName=?";
	
	public static final String DELETE_PROGRAM_OFFERED_QUERY = "DELETE FROM Programs_Offered WHERE ProgramName=?";

	public static final String DELETE_PROGRAM_SCHEDULED_QUERY = "DELETE FROM Programs_Scheduled WHERE Scheduled_program_id=?";

	public static final String LIST_PROGRAMS_OFFERED = "SELECT * FROM Programs_Offered";
	
	public static final String LIST_PROGRAMS_OFFERED_DATES = "SELECT * FROM Programs_Offered WHERE ( start_date BETWEEN ? AND ?)";
	
}
