package com.capg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capg.uas.bean.Applicant;
import com.capg.uas.bean.ProgramOffered;
import com.capg.uas.bean.ProgramScheduled;
import com.capg.uas.bean.Users;
import com.capg.uas.exception.UASException;
import com.capg.uas.util.ConnectionProvider;

public class AdminDaoImpl implements IAdminDao {

	public Logger log = Logger.getLogger("UserDAO");
	private ResultSet resultSet;

	@Override
	public Users getUserByName(String userName) throws UASException {
		Users user = null;
		try (Connection connection = ConnectionProvider.DEFAULT_INSTANCE
				.getConnection();
				PreparedStatement statement = connection
						.prepareStatement(IQueryMapper.GET_USER)) {

			statement.setString(1, userName);

			ResultSet result = statement.executeQuery();
			if (result.next()) {
				user = new Users();
				user.setLoginId(result.getString(1));
				user.setPassword(result.getString(2));
				user.setRole(result.getString(3));
			}
		} catch (SQLException e) {
			log.error(e);
			throw new UASException("Unable To Fetch Records");
		}
		return user;
	}

	@Override
	public String addProgramOffered(ProgramOffered progOffered)
			throws UASException {
		String programName = null;
		
		resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement addStatement = null;
		
		
		if (progOffered != null) {
			
			try {
				addStatement = connection.prepareStatement(IQueryMapper.ADD_PROGRAM_OFFERED_QUERY);
				addStatement.setString(1, progOffered.getProgName());
				addStatement.setString(2, progOffered.getDesc());
				addStatement.setString(3, progOffered.getAppEligibility());
				addStatement.setInt(4, progOffered.getDuration());
				addStatement.setString(5, progOffered.getDegreeOffered());
				int count = addStatement.executeUpdate();
				//System.out.println("value of count is" +count);
				if (count > 0){
					//logger.info("Applicant details added successfully:");
						programName=progOffered.getProgName();
					
				}
				else {
					//logger.error("Insertion failed ");
					throw new UASException("Inserting Program Offered details failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					resultSet.close();
					addStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					//logger.error(sqlException.getMessage());
					throw new UASException("Error in closing database connection");

				}
			}
		}
		return programName;
	}

	@Override
	public String updateProgramOffered(ProgramOffered progOffered)
			throws UASException {
		String programName = null;
		
		resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement updateStatement = null;
		
			try {
				
				updateStatement=connection.prepareStatement(IQueryMapper.UPDATE_PROGRAM_OFFERED_QUERY);
				updateStatement.setString(1, progOffered.getDesc());
				updateStatement.setString(2, progOffered.getAppEligibility());
				updateStatement.setString(3, progOffered.getProgName());
				int count = updateStatement.executeUpdate();

				if (count > 0){
					//logger.info("Applicant details added successfully:");
						programName=progOffered.getProgName();
					
				}
				else {
					//logger.error("Insertion failed ");
					throw new UASException("Updating Program Offered details failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					resultSet.close();
					updateStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					//logger.error(sqlException.getMessage());
					throw new UASException("Error in closing database connection");

				}
			}
			
			return programName;
		}
		

		
	

	@Override
	public boolean deleteProgramOffered(String progName) throws UASException {
		
		boolean result = false;
		
		resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement deleteStatement = null;
		
			try {
				
				deleteStatement=connection.prepareStatement(IQueryMapper.DELETE_PROGRAM_OFFERED_QUERY);
				
				deleteStatement.setString(1, progName);
				int count = deleteStatement.executeUpdate();

				if (count > 0){
					//logger.info("Applicant details added successfully:");
						result = true;
					
				}
				else {
					//logger.error("Insertion failed ");
					throw new UASException("Deleting Program Offered details failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					resultSet.close();
					deleteStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					//logger.error(sqlException.getMessage());
					throw new UASException("Error in closing database connection");

				}
			}
			
			return result;
	}

	@Override
	public List<ProgramOffered> getAllOfferedPrograms() throws UASException {
		
		List<ProgramOffered> programOfferedList = new ArrayList<>();
		ResultSet resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement listStatement = null;
		
		try {
			
			listStatement = connection.prepareStatement(IQueryMapper.LIST_PROGRAMS_OFFERED); 
			
			resultSet = listStatement.executeQuery();
			//programScheduledList = new ArrayList<ProgramScheduled>();
			
			while(resultSet.next()){
				ProgramOffered programOffered = new ProgramOffered();
				programOffered.setProgName(resultSet.getString("ProgramName"));
				programOffered.setDesc(resultSet.getString("description"));
				programOffered.setAppEligibility(resultSet.getString("applicant_eligibility"));
				programOffered.setDuration(resultSet.getInt("duration"));
				programOffered.setDegreeOffered(resultSet.getString("degree_certificate_offered"));
				
				programOfferedList.add(programOffered);
			}

		} catch (SQLException e) {
			//log.error(e);
			throw new UASException("Error in fetching data in DAO");
		} finally
		{
			try 
			{
				resultSet.close();
				listStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Error in closing database connection");
			}
		}
		return programOfferedList;
	}

	@Override
	public String addProgramScheduled(ProgramScheduled progScheduled)
			throws UASException {
		String programId = null;
		
		ResultSet resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement addStatement = null;
		
		
		if (progScheduled != null) {
			
			try {
				addStatement = connection.prepareStatement(IQueryMapper.ADD_PROGRAM_SCHEDULED_QUERY);
				addStatement.setString(1, progScheduled.getScheduleProgId());
				addStatement.setString(2, progScheduled.getProgName());
				addStatement.setString(3, progScheduled.getLocation());
				addStatement.setDate(4, progScheduled.getStart());
				addStatement.setDate(4, progScheduled.getEnd());
				addStatement.setInt(6, progScheduled.getSessionsPerWeek());
				
				int count = addStatement.executeUpdate();
				//System.out.println("value of count is" +count);
				if (count > 0){
					//logger.info("Applicant details added successfully:");
						programId=progScheduled.getScheduleProgId();
					
				}
				else {
					//logger.error("Insertion failed ");
					throw new UASException("Inserting Program Scheduled failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					resultSet.close();
					addStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					//logger.error(sqlException.getMessage());
					throw new UASException("Error in closing database connection");

				}
			}
		}
		return programId;
	}

	@Override
	public boolean deleteProgramScheduled(String progId) throws UASException {
		
		boolean result = false;
		
		resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement deleteStatement = null;
		
			try {
				
				deleteStatement=connection.prepareStatement(IQueryMapper.DELETE_PROGRAM_SCHEDULED_QUERY);
				
				deleteStatement.setString(1, progId);
				int count = deleteStatement.executeUpdate();

				if (count > 0){
					//logger.info("Applicant details added successfully:");
						result = true;
					
				}
				else {
					//logger.error("Insertion failed ");
					throw new UASException("Deleting Program Scheduled failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					resultSet.close();
					deleteStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					//logger.error(sqlException.getMessage());
					throw new UASException("Error in closing database connection");

				}
			}
			
			return result;
	}

	@Override
	public List<ProgramScheduled> getDatedProgramsSchedule(Date fromDateSQL,
			Date toDateSQL) throws UASException {
		List<ProgramScheduled> programScheduleList = new ArrayList<>();
		ResultSet resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement listStatement = null;
		
		try {
			
			listStatement = connection.prepareStatement(IQueryMapper.LIST_PROGRAMS_OFFERED_DATES); 
			listStatement.setDate(1, fromDateSQL);
			listStatement.setDate(2, toDateSQL);
			resultSet = listStatement.executeQuery();
			//programScheduledList = new ArrayList<ProgramScheduled>();
			
			while(resultSet.next()){
				ProgramScheduled programSchedule = new ProgramScheduled();
				programSchedule.setScheduleProgId(resultSet.getString("Scheduled_program_id"));
				programSchedule.setProgName(resultSet.getString("ProgramName"));
				programSchedule.setLocation(resultSet.getString("Location"));
				programSchedule.setStart(resultSet.getDate("start_date"));
				programSchedule.setEnd(resultSet.getDate("end_date"));
				programSchedule.setSessionsPerWeek(resultSet.getInt("session_per_week"));				
				programScheduleList.add(programSchedule);
			}

		} catch (SQLException e) {
			//log.error(e);
			throw new UASException("Error in fetching data in DAO");
		} finally
		{
			try 
			{
				resultSet.close();
				listStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new UASException("Error in closing database connection");
			}
		}
		return programScheduleList;
	}

	@Override
	public List<Applicant> viewCandidates(Applicant applicants)
			throws UASException {
		List<Applicant> appList = null;
		try (
				Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
				PreparedStatement statement = connection
						.prepareStatement(IQueryMapper.FIND_APPLICANT_PROG_ID_STATUS);) {
			
			statement.setString(1, applicants.getScheduleProgId());
			statement.setString(2, applicants.getStatus());
			ResultSet result = statement.executeQuery();

			appList = new ArrayList<Applicant>();
			while (result.next()) {
				Applicant applicant = new Applicant();
				applicant.setAppId(result.getInt("application_id"));
				applicant.setAppName(result.getString("full_name"));
				applicant.setAppDOB(result.getDate("date_of_birth"));
				applicant.setQualification(result
						.getString("highest_qualification"));
				applicant.setMarks(result.getInt("marks_obtained"));
				applicant.setGoals(result.getString("goals"));
				applicant.setEmailId(result.getString("email_id"));
				applicant.setScheduleProgId(result.getString("Scheduled_program_id"));
				applicant.setStatus(result.getString("status"));
				applicant.setDateOfInterview(result.getDate("Date_Of_Interview"));

				appList.add(applicant);
			}

			if (appList.size() == 0)
				appList = null;
		} catch (SQLException e) {
			log.error(e);
			throw new UASException("Unable To Fetch Applicants");
		}
		return appList;
	}

}
