package com.capg.uas.client;

public class MacClientScreen {

}
