package com.capg.uas.dao;

public class MacDaoImpl implements IMacDao {

}
