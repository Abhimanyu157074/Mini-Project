package com.capg.uas.service;

public interface IMacService {

}
