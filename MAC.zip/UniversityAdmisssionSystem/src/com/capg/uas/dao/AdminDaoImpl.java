package com.capg.uas.dao;

public class AdminDaoImpl implements IAdminDao {

}
